# airbnb_predict_first_booking

This Project contains notebooks and API's about to predict the first Airbnb booking by new users.